import Browsing from "./components/Browsing";

export default function Home() {
  return (
    <main className="min-h-screen  ">
      <Browsing />
    </main>
  );
}
