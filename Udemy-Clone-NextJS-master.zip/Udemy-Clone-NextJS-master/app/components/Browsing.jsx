import React from "react";
import HomePage from "./HomePage";

function Browsing() {
  return (
    <div>
      <HomePage />
    </div>
  );
}

export default Browsing;
